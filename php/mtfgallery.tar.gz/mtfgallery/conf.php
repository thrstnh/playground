<?php
/*
 * Mtf_Gallery
 * Datum: 13.02.2005
 * Version: 0.01a
 * Beschreibung: Gallery-Script
 * License: LGPL
 * Copyright: Matflasch | Thorsten Hillebrand
 * eMail: mail@matflasch.de
 * http://www.matflasch.de
*/


// Tabellenprefix, Standard mtf
define("TABLEPREFIX", "mtfgallery_");

// Datenbankdaten
define("DBHOST", "");
define("DBNAME", "");
define("DBUSER", "");
define("DBPASS", "");

// Wenn das Script auf einem Server laeuft, sind die
// FTP-Daten notwendig, weil der PHP/Apache User
// kein Zugriff auf erstellen von Verzeichnissen
// hat. 
define("FTPHOST", "");
define("FTPUSER", "");
define("FTPPASS", "");
?>
