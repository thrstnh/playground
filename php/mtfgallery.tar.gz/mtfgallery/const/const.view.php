<?php
// DON'T CHANGE THIS FILE!'
// DIESE DATEI ERSTELLT SICH SELBST NEU!'
define("VIEWIMGXFX", "true");
define("VIEWBUTTONBAR", "true");
define("VIEWGALLERYNAME", "true");
define("VIEWNAME", "true");
define("VIEWFILESIZE", "true");
define("VIEWIMGSIZE", "true");
define("VIEWVISITS", "true");
define("VIEWINFO", "true");
define("VIEWCOMMENTBANNER", "true");
define("VIEWCOMMENTS", "true");
define("VIEWADDCOMMENT", "true");
?>
