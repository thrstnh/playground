<?php
// DON'T CHANGE THIS FILE!'
// DIESE DATEI ERSTELLT SICH SELBST NEU!'
define("CONF_GALDIR", "/htdocs/mtf_gallery/");
define("CONF_IMGPSITE", "12");
define("CONF_IMGPROW", "4");
define("CONF_UPLOADSPTIME", "10");
define("CONF_IMGBORDER", "0");
define("CONF_SORT", "ASC");
define("CONF_ORDERBY", "id");
define("CONF_TITLE", "Matlfaschs Bilder Gallery");
define("CONF_HOMEPAGE", "http://www.Matflasch.de");
define("CONF_KEYWORDS", "rge Rauschgoldengel Punk Metal Punk-Metal Emsland
");
define("CONF_DESCRIPTION", "Matflaschs Bilder Gallery, geschrieben in PHP mit vielen Funktionen und Einstellungen");
define("CONF_THUMBSIZE", "80");
define("CONF_IMAGESIZE", "640");
define("CONF_SHOWSORTBAR", "true");
define("CONF_SAVEORIGINAL", "true");
define("CONF_CSS", "css2.css");
define("CONF_IMAGEQUALITY", "75");
?>
