<?php
// DON'T CHANGE THIS FILE!'
// DIESE DATEI ERSTELLT SICH SELBST NEU!'
define("THUMB_SHOW_NAME", "true");
define("THUMB_SHOW_VIEWS", "true");
define("THUMB_SHOW_SIZE", "true");
?>
